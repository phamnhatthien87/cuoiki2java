package Controller;

import DAO.UserDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.User;

public class LoginController {

    // ===== DAO (tạo 1 lần) =====
    private UserDAO userDAO = new UserDAO();

    @FXML
    private TextField txtUser;

    @FXML
    private PasswordField txtPass;

    // ==========================
    // HANDLE LOGIN
    // ==========================
    @FXML
    private void handleLogin() {

        String username = txtUser.getText().trim();
        String password = txtPass.getText().trim();

        // 👉 CHECK INPUT
        if (username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Thông báo", "Vui lòng nhập đầy đủ tài khoản và mật khẩu!");
            return;
        }

        User u = userDAO.login(username, password);

        if (u != null) {

            System.out.println("Login success: " + u.getRole());

            // 👉 PHÂN QUYỀN
            if ("borrower".equalsIgnoreCase(u.getRole())) {
                openBorrowerUI(u);
            } else if ("librarian".equalsIgnoreCase(u.getRole())) {
                openLibrarianUI(u);
            } else {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "Role không hợp lệ!");
            }

        } else {
            showAlert(Alert.AlertType.ERROR, "Đăng nhập thất bại", "Sai tài khoản hoặc mật khẩu!");
        }
    }

    // ==========================
    // OPEN BORROWER UI
    // ==========================
    private void openBorrowerUI(User user) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/borrower.fxml"));
            Parent root = loader.load();

            BorrowerController controller = loader.getController();
            controller.setBorrower(user);

            Stage stage = (Stage) txtUser.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Hệ thống - Người mượn");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Không thể mở giao diện Borrower!");
        }
    }

    // ==========================
    // OPEN LIBRARIAN UI
    // ==========================
    private void openLibrarianUI(User user) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/librarian.fxml"));
            Parent root = loader.load();

            LibrarianController controller = loader.getController();
            controller.setLibrarian(user);

            Stage stage = (Stage) txtUser.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Hệ thống - Thủ thư");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Không thể mở giao diện Librarian!");
        }
    }

    // ==========================
    // OPEN SIGN UP
    // ==========================
    @FXML
    public void openSignUp() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/View/signup.fxml"));

            Stage stage = (Stage) txtUser.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Đăng ký tài khoản");

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Không thể mở màn hình đăng ký!");
        }
    }

    // ==========================
    // ALERT
    // ==========================
    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}