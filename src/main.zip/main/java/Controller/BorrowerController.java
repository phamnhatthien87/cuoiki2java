package Controller;

import DAO.BookDAO;
import DAO.BorrowingDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TableRow;
import model.Book;
import model.User;

public class BorrowerController {

    private User borrower;

    @FXML private TableView<Book> tableBooks;
    @FXML private TableColumn<Book, Integer> colId;
    @FXML private TableColumn<Book, String> colTitle;
    @FXML private TableColumn<Book, String> colAuthor;
    @FXML private TableColumn<Book, Integer> colAvailable;
    @FXML
    private TableColumn<Book, String> colCategory;

    @FXML
    private TableColumn<Book, String> colPublisher;

    // ==========================
    // SET USER
    // ==========================
    public void setBorrower(User user){
        this.borrower = user;
        System.out.println("Borrower Login: " + user.getUsername());
    }

    // ==========================
    // INIT
    // ==========================
    @FXML
    public void initialize() {

        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
        colAvailable.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        colCategory.setCellValueFactory(new PropertyValueFactory<>("categoryName"));
        colPublisher.setCellValueFactory(new PropertyValueFactory<>("publisherName"));

        loadBooksData();

        // highlight sách hết
        tableBooks.setRowFactory(tv -> new TableRow<Book>() {
            @Override
            protected void updateItem(Book item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null || empty) {
                    setStyle("");
                } else if (item.getQuantity() <= 0) {
                    setStyle("-fx-background-color: #ffcccc;");
                } else {
                    setStyle("");
                }
            }
        });
    }

    // ==========================
    // LOAD DATA
    // ==========================
    public void loadBooksData() {
        ObservableList<Book> list =
                FXCollections.observableArrayList(new BookDAO().getAll());

        tableBooks.setItems(list);
        tableBooks.refresh();
    }

    // ==========================
    // BORROW BOOK (ĐÃ FIX)
    // ==========================
    @FXML
    public void borrowBook() {

        // 👉 FIX 1: check user null
        if (borrower == null) {
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Chưa xác định người dùng!");
            return;
        }

        Book selectedBook = tableBooks.getSelectionModel().getSelectedItem();

        // 👉 FIX 2: check chọn sách
        if (selectedBook == null) {
            showAlert(Alert.AlertType.WARNING, "Thông báo", "Vui lòng chọn sách!");
            return;
        }

        // 👉 FIX 3: check số lượng
        if (selectedBook.getQuantity() <= 0) {
            showAlert(Alert.AlertType.ERROR, "Lỗi", "Sách đã hết!");
            return;
        }

        BorrowingDAO borrowingDAO = new BorrowingDAO();

        boolean success = borrowingDAO.borrowBookTransaction(
                borrower.getId(),
                selectedBook.getId()
        );

        if (success) {
            loadBooksData();

            String msg = "Bạn đã mượn: " + selectedBook.getTitle();
            showAlert(Alert.AlertType.INFORMATION, "Thành công", msg);

            System.out.println(msg + " — by " + borrower.getUsername());
        } else {
            showAlert(Alert.AlertType.ERROR, "Thất bại", "Không thể mượn sách!");
        }
    }

    // ==========================
    // ALERT (FIX UX)
    // ==========================
    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait(); // 👉 FIX quan trọng
    }
}