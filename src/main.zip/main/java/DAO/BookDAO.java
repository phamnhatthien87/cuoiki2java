package DAO;

import Database.ConnectDB;
import model.Book;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    public List<Book> getAll() {
        return getAllBooks();
    }

    public List<Book> getAllBooks() {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT b.id, b.title, b.author, b.quantity, c.categoryName, p.publisherName " +
                "FROM Books b " +
                "LEFT JOIN Categories c ON b.categoryId = c.id " +
                "LEFT JOIN Publishers p ON b.publisherId = p.id";
        try (Connection conn = ConnectDB.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Book(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getInt("quantity"),
                        rs.getString("categoryName"),
                        rs.getString("publisherName")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insert(Book b) {
        // Bỏ 'id' khỏi danh sách cột nếu id tự tăng (IDENTITY)
        String sql = "INSERT INTO Books(title, author, quantity, categoryId, publisherId) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) { // ĐÃ SỬA: Dùng trực tiếp chuỗi sql

            ps.setString(1, b.getTitle());
            ps.setString(2, b.getAuthor());
            ps.setInt(3, b.getQuantity());
            ps.setInt(4, b.getCategoryId());
            ps.setInt(5, b.getPublisherId());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Books WHERE id = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
    }
}